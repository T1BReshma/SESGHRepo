
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV1.Models;
using SESWebAPIV1.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkTeamName=397860

namespace SESWebAPIV1.APIServices
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : Controller
    {
        private readonly ITeamRepository<int, Team> _repository;

        public TeamController(ITeamRepository<int, Team> Repository)
        {
            _repository = Repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Team>>> GetAll()
        {
            var teams = await _repository.GetAll();
            return teams.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Team>> Post(Team Team)
        {
            return await _repository.Add(Team);
        }
        [HttpGet]
        [Route("GetTeamById/{id}")]
        public async Task<ActionResult<Team>> Get(int id)
        {
            return await _repository.Get(id);
        }

        [HttpPut]
        public async Task<ActionResult<Team>> Update(Team Team)
        {
            return await _repository.Update(Team);

        }
        [HttpDelete]
        public async Task<ActionResult<Team>> Delete(int id)
        {
            return await _repository.Delete(id);
        }
    }
}

