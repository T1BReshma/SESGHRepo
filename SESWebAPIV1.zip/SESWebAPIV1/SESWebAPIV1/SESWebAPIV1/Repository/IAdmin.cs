using System;
using SESWebAPIV1.Models;

namespace SESWebAPIV1.Repository
{
    public interface IAdmin
    {
        // Admin would be required to login and register
        // For Admin DTO to work we need to pass the login parameters for the login function
        AdminLoginDTO Login(AdminLoginDTO admin);

        //AdminLoginDTO Register(AdminDTO admin);
    }
}
