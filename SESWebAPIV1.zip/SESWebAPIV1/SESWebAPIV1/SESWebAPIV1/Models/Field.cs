
using System.ComponentModel.DataAnnotations;

namespace SESWebAPIV1.Models
{
    public class Field
    {
        [Key]
        public int FieldId { get; set; }

        public string FieldName { get; set; }

        public string FieldCity { get; set; }

        public int MatchId { get; set; }

        public int FieldCapacity { get; set; }

        public string FieldURL { get; set; }

    }
}



