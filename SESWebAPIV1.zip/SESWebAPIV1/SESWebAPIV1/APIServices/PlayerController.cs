﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV1.Models;
using SESWebAPIV1.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkTeamName=397860

namespace SESWebAPIV1.APIServices
{
    // save it for front end
    [Route("api/v1/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        private readonly IPlayerRepository<int, Player> _Repository;

        public PlayerController(IPlayerRepository<int, Player> Repository)
        {
            _Repository = Repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Player>>> GetAll()
        {
            var players = await _Repository.GetAll();
            return players.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Player>> Post(Player player)
        {
            return await _Repository.Add(player);
        }
        [HttpGet]
        [Route("GetPlayerByID/{id}")]
        public async Task<ActionResult<Player>> Get(int id)
        {
            return await _Repository.Get(id);
        }

        [HttpPut]
        public async Task<ActionResult<Player>> Update(Player player)
        {
            return await _Repository.Update(player);

        }
        [HttpDelete]
        public async Task<ActionResult<Player>> Delete(int id)
        {
            return await _Repository.Delete(id);
        }
    }
}