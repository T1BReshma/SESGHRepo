using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV1.Models;
using SESWebAPIV1.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SESWebAPIV1.APIServices
{
    [Route("api/[controller]")]
    public class FieldController : Controller
    {
        private readonly IFieldRepository<int, Field> _repository;

        public FieldController(IFieldRepository<int, Field> Repository)
        {
            _repository = Repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Field>>> GetAll()
        {
            var Fields = await _repository.GetAll();
            return Fields.ToList();
        }

        [HttpGet]
        [Route("GetFieldByID/{id}")]
        public async Task<ActionResult<Field>> Get(int id)
        {
            return await _repository.Get(id);
        }
    }
}