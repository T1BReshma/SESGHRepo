﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV1.Models;
using SESWebAPIV1.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkTeamName=397860

namespace SESWebAPIV1.APIServices
{
    [Route("api/[controller]")]
    public class TeamController : Controller
    {
        private readonly ITeamRepository<int, Team> _Repository;

        public TeamController(ITeamRepository<int, Team> Repository)
        {
            _Repository = Repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Team>>> GetAll()
        {
            var teams = await _Repository.GetAll();
            return teams.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Team>> Post(Team Team)
        {
            return await _Repository.Add(Team);
        }
        [HttpGet]
        [Route("GetTeamById/{id}")]
        public async Task<ActionResult<Team>> Get(int id)
        {
            return await _Repository.Get(id);
        }

        [HttpPut]
        public async Task<ActionResult<Team>> Update(Team Team)
        {
            return await _Repository.Update(Team);

        }
        [HttpDelete]
        public async Task<ActionResult<Team>> Delete(int id)
        {
            return await _Repository.Delete(id);
        }
    }
}

