using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SESWebAPIV1.Repository
{
    public interface IFieldRepository<F, T>
    {

        Task<T> Get(F key);

        Task<ICollection<T>> GetAll();
    }
}
