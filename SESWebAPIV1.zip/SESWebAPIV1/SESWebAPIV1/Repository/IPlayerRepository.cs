using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SESWebAPIV1.Repository
{
    public interface IPlayerRepository<N, P>
    {
        // async - works opposite of synchronise
        Task<P> Get(N key);

        Task<P> Update(P item);

        Task<P> Delete(N key);

        Task<P> Add(P item);

        Task<ICollection<P>> GetAll();
    }
}
