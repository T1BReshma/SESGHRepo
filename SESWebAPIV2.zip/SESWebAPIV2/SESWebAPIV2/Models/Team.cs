﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SESWebAPIV2.Models
{
    public class Team
    {
        [Key]
        public int TeamId { get; set; }

        public string TeamName { get; set; }

        public string Country { get; set; }

        public virtual ICollection<Player> Player { get; set; }
    }
}
