﻿using System;
using SESWebAPIV2.Models;

using Microsoft.EntityFrameworkCore;

namespace SESWebAPIV2.Repository
{
    public class MatchContext : DbContext
    {
        public MatchContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Match> Matches { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Field> Fields { get; set; }
        public DbSet<Booking> Bookings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Player>()
            //        .Property(p => p.FullName)
            //        .IsRequired();

            //modelBuilder.Entity<Team>()
            //        .Property(t => t.TeamName)
            //        .IsRequired();

            //modelBuilder.Entity<Match>()
            //        .Property(m => m.TeamA)
            //        .IsRequired();

            modelBuilder.Entity<Player>().HasData(new Player()
            {
                // Id will start from 1
                Id = 1, // Id is now NON-NULLABLE
                TeamId = 101,
                FullName = "Robert Lewandowski",
                JerseyNumber = 9,
                FieldPosition = "Forward",
            });

            modelBuilder.Entity<Team>().HasData(new Team()
            {
                // Id will start from 1
                TeamId = 101,
                TeamName = "Liverpool",
                Country = "Singapore"
            });

            modelBuilder.Entity<Match>().HasData(new Match()
            {
                // Id will start from 1
               MatchId = 1,
                TeamA = "Liverpool",
                TeamAURL = "string1",
                TeamB = "Man U",
                TeamBURL = "string2",
                Date = "11-05-2022",
                Time = "12:30 PM",
                Location = "Singapore",
            });;
        }
    }
}