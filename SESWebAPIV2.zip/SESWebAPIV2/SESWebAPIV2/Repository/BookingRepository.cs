﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;
using SESWebAPIV2.Repository;

namespace SESWebAPIV2.Repository
{
    public class BookingRepository : IBookingRepository<int, Booking>
    {
        private readonly MatchContext _context;
        private readonly ILogger<BookingRepository> _logger;

        public BookingRepository(MatchContext context, ILogger<BookingRepository> logger)
        {
            _context = context;
            _logger = logger;
        }
        public async Task<Booking> Add(Booking item)
        {
            try
            {
                _context.Bookings.Add(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception)
            {
                _logger.LogError("Error in adding Booking");
            }
            return null;
        }

        public async Task<Booking> Delete(int key)
        {
            try
            {
                var item = await Get(key);
                _context.Bookings.Remove(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception)
            {
                _logger.LogError("Error in deleting Booking");
            }
            return null;
        }

        public async Task<Booking> Get(int key)
        {
            try
            {
                var item = _context.Bookings.FirstOrDefault(b => b.BookingId == key);

                return item;
            }
            catch (Exception)
            {
                _logger.LogError("Error in Getting Booking");
            }
            return null;
        }

        public async Task<ICollection<Booking>> GetAll()
        {
            return _context.Bookings.ToList();
        }

        public async Task<Booking> Update(Booking item)
        {
            try
            {
                var Booking = await Get(item.BookingId);
                Booking.Quantity = item.Quantity;
                Booking.Price = item.Price;
                Booking.MatchName = item.MatchName;
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception)
            {
                _logger.LogError("Error in updating Booking");
            }
            return null;
        }
    }
}

