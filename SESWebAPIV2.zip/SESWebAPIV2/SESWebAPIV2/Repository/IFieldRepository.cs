﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SESWebAPIV2.Repository
{
    public interface IFieldRepository<F, T>
    {

        Task<T> Get(F key);

        Task<ICollection<T>> GetAll();
    }
}
